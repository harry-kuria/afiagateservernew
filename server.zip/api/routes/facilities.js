const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();

const Pool = require('pg').Pool
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'afiagate',
    password: 'H@rri50n',
    port: 5432
  })

const storage = multer.diskStorage({
    destination: "./facilityimages", /*(req, file,cb) => {
        cb(null, __dirname+'/images/')
    },*/
    filename: (req, file, cb) => {
        console.log(file);
        return cb(null,`${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
    }
})

const upload = multer({storage: storage });


//get facilities
router.get('/',(req, res, next)=>{
    const sqlSelect = "SELECT * FROM facilities"; 
    pool.query(sqlSelect, (error, result)=>{
        res.send(result.rows);
    })
});

//get a facility
router.get('/:facilityId',(req, res, next)=>{
    res.status(200).json({
        message: 'Get a facility using GET',
        id: req.params.facilityId
    });
});

//post facilities
router.post('/',upload.single('photourl'),(req, res, next)=>{
    const photoURL = `http://192.168.2.119:5000/${req.file.path}`;
    const facilityname = req.body.facilityname;
    const facilityaddress = req.body.facilityaddress;
    const contact = req.body.contact;
    
    //const photoURL = `http://localhost:5000/${req.file.path}`;
    
    const sqlInsert = 'INSERT INTO facilities (photourl, facilityname, facilityaddress, contact) VALUES ($1, $2, $3, $4);';
    pool.query(sqlInsert,[ photoURL,facilityname, facilityaddress, contact ], (error, results) =>{
        if (error) { 
            throw error
          }
          
          
          res.status(200).json({
            
            message: "Successful insertion to database",
            
            photoURL: photoURL,
            facilityname: facilityname,
            facilityaddress: facilityaddress,
            contact: contact
      //      photoURL: photoURL
            
        })
       // res.send(results.rows);
    console.log(results.rows);
          
    });
    
});

//delete facilities
router.delete('/:facilityId',(req, res, next)=>{
    res.status(200).json({
        message: 'delete a facility using DELETE',
        id: req.params.facilityId
    });
});
module.exports=router;